﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.IO;
using System.Collections;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        string selectedFileName = string.Empty;
        string directoryPath = string.Empty;
        

        public Window1()
        {
            InitializeComponent();
        }
        private void BrowseButton_Click(object sender, RoutedEventArgs e)
        {
            //MessageBox.Show("Hello");
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            dlg.InitialDirectory = "c:\\";
            dlg.Filter = "Image files (*.png)|*.png|All Files (*.*)|*.*";
            dlg.RestoreDirectory = true;
            
            if (dlg.ShowDialog() == true)
            {
                selectedFileName = dlg.FileName;
                directoryPath = System.IO.Path.GetDirectoryName(selectedFileName);
                FileNameLabel.Content = selectedFileName;
                BitmapImage bitmap = new BitmapImage();
                bitmap.BeginInit();
                bitmap.UriSource = new Uri(selectedFileName);
                bitmap.EndInit();
                ImageViewer1.Source = bitmap;
            }
        }

        private void PrevButton_Click(object sender, RoutedEventArgs e)
        {
            string[] fileEntries = Directory.GetFiles(directoryPath,"*.png");
            string[] fileEntries1 = Directory.GetFiles(directoryPath, "*.jpg");
            fileEntries.Concat(fileEntries);
           // MessageBox msgbox= MessageBox
            int size = fileEntries.Length;
            int index = Array.IndexOf(fileEntries, selectedFileName);
           // MessageBox.Show(index.ToString());
            if (index == 0)
                index = size ;
                selectedFileName = fileEntries[(index-1)%size];
                MessageBox.Show(selectedFileName);
                directoryPath = System.IO.Path.GetDirectoryName(selectedFileName);
                FileNameLabel.Content = selectedFileName;
                BitmapImage bitmap = new BitmapImage();
                bitmap.BeginInit();
                bitmap.UriSource = new Uri(selectedFileName);
                bitmap.EndInit();
                ImageViewer1.Source = bitmap;
            

        }

        private void NextButton_Click(object sender, RoutedEventArgs e)
        {
            string[] fileEntries = Directory.GetFiles(directoryPath, "*.png");
            string[] fileEntries1 = Directory.GetFiles(directoryPath, "*.jpg");
            fileEntries.Concat(fileEntries);
           
            int size = fileEntries.Length;
          //  MessageBox.Show(size.ToString());
            int index = Array.IndexOf(fileEntries, selectedFileName);
            //MessageBox.Show(selectedFileName);
            //MessageBox.Show(index.ToString());
            
                selectedFileName = fileEntries[(index + 1) % size];
                directoryPath = System.IO.Path.GetDirectoryName(selectedFileName);
                FileNameLabel.Content = selectedFileName;
                BitmapImage bitmap = new BitmapImage();
                bitmap.BeginInit();
                bitmap.UriSource = new Uri(selectedFileName);
                bitmap.EndInit();
                ImageViewer1.Source = bitmap;
            
        }

        
    }
   
}
