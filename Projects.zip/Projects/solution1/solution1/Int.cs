﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace solution1
{
   public class Int
    {
        private int intval;
        public Int()
        {
            intval = 0;
        }
        public void setvalue(int tempval)
        {
            intval = tempval;
        }

        public int getvalue()
        {

            return intval;
        }
        public int getsum(Int number1, Int number2)
        {
            return number1.getvalue() + number2.getvalue(); 
        }
        public static void Main(string[] args)
        {
            Int i = new Int();
            Console.WriteLine("enter first integer");
            i.setvalue(Int32.Parse(Console.ReadLine()));
           // Console.WriteLine("first num is:" + i.getvalue());
            Console.WriteLine("enter second integer");
            Int i1 = new Int();
            i1.setvalue(Int32.Parse(Console.ReadLine()));
            Console.WriteLine("sum is" + new Int().getsum(i,i1));       
        
        }
    
    
    
    }

}
