﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace solution1
{
  public  class tollbooth
    {
        private int tollcar;
        private double money;
        public tollbooth()
        {
            tollcar = 0;
            money = 0;
        
        }
        public void payingcar()
        {
            tollcar++;
            money = money + .50;

        }
        public void nonpayingcar()

        {
            tollcar++;
        }
        public void display()
        {
            Console.WriteLine(tollcar);
            Console.WriteLine(money);
        
        }
         public static void Main(string[] args)
         { 
        Console.WriteLine("total paying car");
        tollbooth i = new tollbooth();
        i.payingcar
         

  
           }
}
