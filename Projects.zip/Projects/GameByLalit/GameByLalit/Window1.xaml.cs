﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GameByLalit
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public int Rand;
        public int score;
        public Window1()
        {
            InitializeComponent();
            Random rand=new Random();
            Rand = (rand.Next(100));
            score = 10;
            label1.Content = "START GAME";
            label2.Content = "Score  : 10" ;
           // MessageBox.Show(Rand.ToString());
        }
        public void clear()
        {
            Random rand = new Random();
            Rand = (rand.Next(100));
           // Rand = ((rand.Next()) * 1000) % 100;
            score = 10;
            label1.Content = "START GAME";
            label2.Content = "Score  : 10" ; 
        }

        

        private void button1_Click(object sender, RoutedEventArgs e)
        {
           int input= Int32.Parse(textBox1.Text);
           if (input == Rand)
            {
                score = score - 1;
                label1.Content = "You Won, Score" ;
            //   score.ToString;
         //       clear();
                //MessageBox.Show("1");
            
           }
           else if (input < (Rand - 20))
            {
                label1.Content = "Too Low";
                score = score - 1;
                if (score <= 0)
                {

                    label1.Content = "You Lost";
                    textBox1.IsEnabled = false;
                }
            //    MessageBox.Show("2");
            }
           else if (input < Rand)
           {
               label1.Content = "Low";
               score = score - 1;
               if (score < 0)
                   label1.Content = "You Lost";
          //     MessageBox.Show("3");
           }
           else if (input > (Rand + 20))
            {
                label1.Content = "Too High";
                score = score - 1;
                if (score < 0)
                    label1.Content = "You Lost";
           //     MessageBox.Show("4");
            }
           else if (input > Rand)
           {
               label1.Content = "High";
               score = score - 1;
               if (score < 0)
                   label1.Content = "You Lost";
               //   MessageBox.Show("5");
           }
           
            label2.Content = "Score  :"+score.ToString();
           // label1.Content = "";
            textBox1.Text = "";

        }
    }
}
