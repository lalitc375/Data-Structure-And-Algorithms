﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
       public int firstNumber;
        public int secondNumber;
        public  char operatorBetween;
        public int flag;
        public Form1()
        {
            InitializeComponent();
            flag = 0;
            firstNumber = 0;
            secondNumber = 0;
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            /*if (flag == 0)
            {

                firstNumber = firstNumber * 10 + 1;
                
            }
            else if (flag == 1)
            {
                secondNumber = secondNumber * 10 + 1;
            }

            update();*/
        }
        private void update()
        {
            textBox1.Text = firstNumber.ToString();
            if (flag == 1)
            {
                textBox1.Text += operatorBetween.ToString();
                textBox1.Text += secondNumber.ToString();
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (flag == 0)
                firstNumber = firstNumber * 10 + 2;
            else if (flag == 1)
            {
                secondNumber = secondNumber * 10 + 2;
            }
            update();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (flag == 0)
                firstNumber = firstNumber * 10 + 3;
            else if (flag == 1)
            {
                secondNumber = secondNumber * 10 + 3;
            }
            update();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (flag == 0)
                firstNumber = firstNumber * 10 + 4;
            else if (flag == 1)
            {
                secondNumber = secondNumber * 10 + 4;
            }
            update();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (flag == 0)
                firstNumber = firstNumber * 10 + 5;
            else if (flag == 1)
            {
                secondNumber = secondNumber * 10 + 5;
            }
            update();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (flag == 0)
                firstNumber = firstNumber * 10 + 6;
            else if (flag == 1)
            {
                secondNumber = secondNumber * 10 + 6;
            }
            update();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (flag == 0)
                firstNumber = firstNumber * 10 + 7;
            else if (flag == 1)
            {
                secondNumber = secondNumber * 10 + 7;
            }
            update();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (flag == 0)
                firstNumber = firstNumber * 10 + 8;
            else if (flag == 1)
            {
                secondNumber = secondNumber * 10 + 8;
            }
            update();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (flag == 0)
                firstNumber = firstNumber * 10 + 9;
            else if (flag == 1)
            {
                secondNumber = secondNumber * 10 + 9;
            }
            update();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (flag == 0)
                firstNumber = firstNumber * 10 + 0;
            else if (flag == 1)
            {
                secondNumber = secondNumber * 10 + 0;
            }
            update();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (flag == 0)
                firstNumber = firstNumber * 10 + 1;
            else if (flag == 1)
            {
                secondNumber = secondNumber * 10 + 1;
            }
            update();

        }

        private void button12_Click(object sender, EventArgs e)
        {
            operatorBetween = '+';
            if (flag == 0)
                textBox1.Text = textBox1.Text + operatorBetween.ToString();
            flag = 1;
            

        }

        private void button13_Click(object sender, EventArgs e)
        {
            operatorBetween = '-';
            if (flag == 0)
                textBox1.Text = textBox1.Text + operatorBetween.ToString();
            flag = 1;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            operatorBetween = '*';
            if (flag == 0)
                textBox1.Text = textBox1.Text + operatorBetween.ToString();
            flag = 1;

        }

        private void button15_Click(object sender, EventArgs e)
        {
            operatorBetween = '/';
            if (flag == 0)
                textBox1.Text = textBox1.Text + operatorBetween.ToString();
            flag = 1;

        }

        private void button16_Click(object sender, EventArgs e)
        {
            Calculate();
            
        }
       public void Calculate()
        {
           int ans=0;
           if(operatorBetween=='+')
               ans=firstNumber+secondNumber;
           else if(operatorBetween=='-')
               ans=firstNumber-secondNumber;
           else if(operatorBetween=='/')
               ans=firstNumber/secondNumber;
           else if(operatorBetween=='*')
               ans=firstNumber*secondNumber;
           textBox1.Text = ans.ToString();

        }
       public void clear()
       {
           textBox1.Text = "";
           firstNumber = 0;
           secondNumber = 0;
           operatorBetween = ' ';
           flag = 0;
       }


       private void button17_Click(object sender, EventArgs e)
       {
           clear();
       }

       private void Form1_Load(object sender, EventArgs e)
       {

       }

       private void button18_Click(object sender, EventArgs e)
       {

       }
       
    }
}
